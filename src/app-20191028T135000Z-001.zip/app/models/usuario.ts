export class Usuario{

    constructor(
        public firstname : string,
        public lastname : string,
        public identificacion : number,
        public birthdate : Date
    ){}
    
}